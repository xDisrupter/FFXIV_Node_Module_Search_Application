This is a command line application utalizing a cutom node module.
This custom node module accepts a user's command line arguments, and performs 
a search upon the FFXIV database based on the keyword or term. This then returns 
the search results for the user to make a selection and recieve further details
for the selected item. This application utalizing Node.js, and additional 
node plugins: inquirer, yargs, and superagent
