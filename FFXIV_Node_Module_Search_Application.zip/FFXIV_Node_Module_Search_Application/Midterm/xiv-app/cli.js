const yargs = require("yargs");
//console.log(yargs.argv._);
const app = require("./app.js");

yargs
  .usage("$0: Usage <cmd> [options]")
  // add search command
  .command({
    command: "search",
    desc: "Enter a search",
    handler: (argv) => {
      // console.log(argv);
      app.search(argv._);
    },
  })
  //add a help function
  .help("help").argv;
