const inquirer = require("inquirer");
const xiv = require("FFXIVModule");
async function search(terms) {
  try {
    // call construct String to separate the search command from the string to be searched in the query
    const query = constructString(terms);

    //recieve the returned object query from the api call
    const res = await xiv.XIVAPI(query);
    //The return is two objects
    //the first object are the search details Pagination, the second is the list of returned objects Results
    items = res.Results;

    //store the picked item(obj) from the promp list into the pick variable
    console.log(`Total Results: ${res.Pagination.Results}`);
    const pick = await _itemPrompt(items);
    //loop through the list of item objects to find to matching choice from user input and store hte selection inside of pickObj
    const pickObj = await getItem(pick, items);
    //Print the users selection in a clean format

    printItem(pickObj);
  } catch (error) {
    console.log(error);
  }
}
//method used to search through the list of item objects(items) and find the match based on the users selection from prompt(str)
const getItem = async (str, items) => {
  //initialize an empty object
  let item = {};
  //iterate through the list of item objects
  items.forEach((element) => {
    //if a match for the users choice is found among the list of objects set item to that element
    if (element.Name !== undefined) {
      //compare object names
      if (element.Name === str.items[0]) {
        item = element;
      }
    }
  });
  return item;
};

const _itemPrompt = async (objectsAr) => {
  // return a new array of objects where name is what is displayed to the user
  // and value is what is returned from the inquirer prompt
  const displayItems = objectsAr.map((item) => {
    return { name: `${item.Name}`, key: `${item.ID}` };
  });
  //used map to get an array of objects with names and keys to match each object.
  // create an inquirer checkbox prompt
  return inquirer.prompt([
    {
      type: "checkbox",
      name: "items",
      message: "select item to choose",

      // display the items to the user for them to select
      choices: displayItems,
      validate: (pick) => {
        if (pick.length === 1) {
          //allow the user to only pick one selection from hte seach query
          return true;
        } else {
          return "You may only pick one";
        }
      },
    },
  ]);
};
//This method is used to print a single item as a parameter
const printItem = (item) => {
  console.log(
    `Name: ${item.Name}\nLevel Equip: ${item.LevelEquip} \nLevel Item: ${item.LevelItem}\nIcon png: ${item.Icon}`
  );
};
//Method used to construct the query string and separate the use command
const constructString = (ar) => {
  let str = "";
  for (let i = 1; i < ar.length; i++) {
    str += ar[i];
  }
  return str;
};

// export the search function so that it can be used in the cli.js
module.exports = {
  search,
};
